"use strict";
/*eslint-disable */

const SERVER_ROOT = 'http://localhost:3000';

let login = document.getElementById("loginBtn");

login.onclick = function () {
    console.log("yes")
    // const username = document.getElementById("username").value;
    // const password = document.getElementById("password").value;
    // console.log(username, password);
    // fetch(`${SERVER_ROOT}/api/auth/login`, {
    //     method: 'POST',
    //     body: JSON.stringify({
    //         username,
    //         password
    //     }),
    //     headers: {
    //         'Content-Type': 'application/json'
    //     }
    // }).then(response => response.json())
    //     .then(data => console.log(data));
}